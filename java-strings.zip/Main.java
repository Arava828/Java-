/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main {
    public static void main(String[] args) {
        String text = "  Hello, Java World!  ";

        System.out.println(text.length());              // 22
        System.out.println(text.trim());                // "Hello, Java World!"
        System.out.println(text.toUpperCase());         // "  HELLO, JAVA WORLD!  "
        System.out.println(text.toLowerCase());         // "  hello, java world!  "
        System.out.println(text.charAt(2));             // H
        System.out.println(text.indexOf("Java"));       // 9
        System.out.println(text.contains("World"));     // true
        System.out.println(text.replace("Java", "Python")); // "  Hello, Python World!  "
        System.out.println(text.trim().substring(7));   // "Java World!"
        System.out.println(text.trim().substring(0, 5)); // "Hello"
        System.out.println("apple".equals("apple"));    // true
        System.out.println("Apple".equalsIgnoreCase("apple")); // true
        System.out.println("apple".compareTo("banana")); // negative number
        System.out.println(text.isEmpty());             // false

        // split into an array
        String[] words = "red,green,blue".split(",");
        for (String w : words) {
            System.out.println(w);
        }
    }
}